# ioai_preps
<ul>
<li>2024 - задачи 2024 года</li>
<li>APOAI - задачи с APOAI</li>
</ul>
